from secret import flag
from sage.all import *
from random import randint

G = GF(2 ** 8)
PR = PolynomialRing(G, name='x')
x = PR.gen(0)

alphas = [G.gen() ** i for i in range(4)]
g = (x - alphas[0]) * (x - alphas[1]) * (x - alphas[2]) * (x - alphas[3])

def encode_block(message: list):
    message = [G(Integer(m).digits(2)) for m in message]
    message = PR(message)

    return (message * g).coefficients()

def encode(message: bytes):
    if len(message) % 4 != 0:
        message += b'\x00' * (4 - len(message) % 4)
    
    blocks = [list(message[i:i+4]) for i in range(0, len(message), 4)]
    codes = []
    for block in blocks:
        this_block = encode_block(block)
        error_pos_i = randint(0, 7)
        error_pos_j = randint(0, 7)
        error_offset_1 = G.random_element()
        error_offset_2 = G.random_element()

        this_block[error_pos_i] += error_offset_1
        this_block[error_pos_j] += error_offset_2

        codes.extend(this_block)

    return codes

code = encode(flag)
print([each.to_integer() for each in code])

# Output:
# [184, 223, 148, 146, 10, 116, 86, 233, 126, 137, 251, 6, 255, 57, 22, 100, 92, 186, 101, 244, 248, 207, 202, 115, 162, 171, 254, 21, 226, 94, 171, 119, 129, 190, 28, 183, 17, 235, 58, 95, 92, 49, 30, 215, 11, 126, 127, 48, 209, 5, 54, 145, 248, 195, 146, 114, 92, 188, 219, 122, 134, 188, 128, 125]